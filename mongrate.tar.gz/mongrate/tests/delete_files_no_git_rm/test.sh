#!/bin/bash
echo "delete_file.sh test"
echo "test db port=$MONGRATE_TEST_DB_PORT"
mkdir ./testdata

if [ $? -eq 0 ]
then
    echo "created ./testdata directory"
else
    echo "./testdata exists, it should not, test cannot continue"
    exit 1
fi
mkdir -p ./db/mongo/migrations/common
if [ $? -eq 0 ]
then
    echo "created ./db/mongo/migrations/common directory"
else
    echo "./db/mongo/migrations/common exists, it should not, test cannot continue"
    exit 1
fi

mongod --dbpath ./testdata --logpath ./testdata/mongod.log --fork --port $MONGRATE_TEST_DB_PORT

if [ $? -eq 0 ]
then
    echo "test mongod started successfully"
else
    echo "unable to start test mongod"
    exit 1
fi


git init
python $MONGRATE_HOME/mongrate.py --action generate_migration --migration-id ALPHA
python $MONGRATE_HOME/mongrate.py --action generate_migration --migration-id BETA
git add db/mongo/migrations/common/ALPHA.js
git add db/mongo/migrations/common/BETA.js
git commit -a -m 'first commit'
first_commit=$(git rev-list --all)
rm db/mongo/migrations/common/BETA.js
#git commit -a -m 'second commit'
#second_commit=$(git rev-list --all | head -1)

# now repo is in 2nd commit state - to apply the first changes, we need to checkout
#echo "Checking out $first_commit"
#git checkout --quiet $first_commit
#echo "Rolling forward to first commit $first_commit"

python $MONGRATE_HOME/mongrate.py --action initialize --verbose 
python $MONGRATE_HOME/mongrate.py --action migrate --git-commit $first_commit --verbose


if [ $? -eq 0 ]
then
    echo "test FAILED, mongrate should have detected staged changes"
    ret=1
else
    echo "test OK, mongrate returned an error"
    ret=0
fi




echo "Test complete, cleaning up"

mongo admin --port=$MONGRATE_TEST_DB_PORT --eval 'db.shutdownServer()'
rm -rf testdata/
rm -rf .git/
rm -rf db/
exit $ret
