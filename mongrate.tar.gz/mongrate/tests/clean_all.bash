#!/bin/bash
echo "starting full test run"
export MONGRATE_TEST_DB_PORT=20187
export MONGRATE_HOME=$(realpath ..)

for testdata in ./*/testdata; do   
    echo "cleaning $testdata"; 
    rm -rf $testdata

done;
