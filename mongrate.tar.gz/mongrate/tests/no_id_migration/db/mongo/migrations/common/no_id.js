/*************************
* MongoDB Migration
*
* Generated on 2016-11-08 15:01:51.986910
* _id : alpha
**************************/

migration = {
  'runAfter' : [],
  'onLoad' : function() {
      // TODO: Add onLoad logic here
      print('I don\'t have any _id! onLoad');
      },
  'up' : function() {
      // TODO: rollforward logic
      // TODO: Be sure do 'use' right right database!
      },
  'down' : function() {
      // TODO: Add undo/rollback logic here
      // TODO: Be sure do 'use' right right database!
      },
  'info' : function() {
      // output information on this migration for reporting
      print('migration : ' + this._id)
      },
}

mongrate.exports = migration;
