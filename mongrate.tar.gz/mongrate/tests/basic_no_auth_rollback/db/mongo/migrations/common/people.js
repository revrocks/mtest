/*************************
* MongoDB Migration
*
* Generated on 2016-11-16 10:40:48.691727
* _id : people
**************************/

migration = {
  '_id' : 'people',
  'runAfter' : [],
  'onLoad' : function() {
      // TODO: Add onLoad logic here
      },
  'up' : function() {
      // TODO: rollforward logic
      // TODO: Be sure do 'use' right right database!
      },
  'down' : function() {
      // TODO: Add undo/rollback logic here
      // TODO: Be sure do 'use' right right database!
      },
  'info' : function() {
      // output information on this migration for reporting
      print('migration : ' + this._id)
      },
}

mongrate.exports = migration;
