/*************************
* MongoDB Migration
*
* Generated on 2016-11-16 12:23:05.635059
* _id : alpha
**************************/

migration = {
  '_id' : 'alpha',
  'runAfter' : [],
  'onLoad' : function() {
      // TODO: Add onLoad logic here
      },
  'up' : function() {
      // TODO: rollforward logic
      // TODO: Be sure do 'use' right right database!
      },
  'down' : function() {
      // TODO: Add undo/rollback logic here
      // TODO: Be sure do 'use' right right database!
      },
  'info' : function() {
      // output information on this migration for reporting
      print('migration : ' + this._id)
      },
}

mongrate.exports = migration;
