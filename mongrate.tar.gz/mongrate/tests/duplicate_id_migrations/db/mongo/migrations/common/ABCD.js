/*************************
* MongoDB Migration
*
* Generated on 2016-11-09 11:59:39.077261
* _id : ABCD
**************************/

migration = {
  '_id' : 'ABCD',
  'runAfter' : [],
  'onLoad' : function() {
      // TODO: Add onLoad logic here
      print('onLoad ABDC');
      },
  'up' : function() {
      // TODO: rollforward logic
      // TODO: Be sure do 'use' right right database!
      },
  'down' : function() {
      // TODO: Add undo/rollback logic here
      // TODO: Be sure do 'use' right right database!
      },
  'info' : function() {
      // output information on this migration for reporting
      print('migration : ' + this._id)
      },
}

mongrate.exports = migration;
