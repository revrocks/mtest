#!/bin/bash
echo "auth_cmdline.sh test"
echo "test db port=$MONGRATE_TEST_DB_PORT"
mkdir ./testdata
if [ $? -eq 0 ]
then
    echo "created ./testdata directory"
else
    echo "./testdata exists, it should not, test cannot continue"
    exit 1
fi

mongod --dbpath ./testdata --logpath ./testdata/mongod.log --fork --port $MONGRATE_TEST_DB_PORT

if [ $? -eq 0 ]
then
    echo "test mongod started successfully"
    echo "pausing 1 second to let mongod fully start"
    sleep 1
else
    echo "unable to start test mongod"
    exit 1
fi

# create test user
echo "Creating mongodb user for test"
mongo admin --port $MONGRATE_TEST_DB_PORT --eval 'db.createUser({"user":"slim","pwd":"jim","roles":["root"]});'
mongo test --port $MONGRATE_TEST_DB_PORT --eval 'db.createUser({"user":"tito","pwd":"tata","roles":["readWrite"]});'

mongo admin --port=$MONGRATE_TEST_DB_PORT --eval 'db.shutdownServer()'
echo "Pausing for 2 seconds to reboot test mongod with authentication enabled"
sleep 2
mongod --dbpath ./testdata --logpath ./testdata/mongod.log --fork \
       --port $MONGRATE_TEST_DB_PORT --auth

if [ $? -eq 0 ]
then
    echo "test mongod with auth started successfully"
else
    echo "unable to start test mongod with auth"
    exit 1
fi

latest_commit=$(git rev-list --all | head -1)
echo "Rolling forward to latest commit $latest_commit"

python $MONGRATE_HOME/mongrate.py --action initialize --verbose --user slim --password jim --authenticationDatabase admin 
python $MONGRATE_HOME/mongrate.py --action migrate --git-commit $latest_commit \
--verbose --user slim --password jim --authenticationDatabase admin 


ret=0
python $MONGRATE_HOME/mongrate.py --action status \
--verbose --user tito --password tata --authenticationDatabase test 
if [ $? -eq 0 ]
then
    echo "test FAILED, since should not be able to read on admin db"
    ret=1
else
    echo "test OK"
    ret=0
fi

mongo admin -u slim -p jim --port=$MONGRATE_TEST_DB_PORT --eval 'db.shutdownServer()'
rm -rf testdata/
exit $ret

