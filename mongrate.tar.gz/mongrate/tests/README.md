Tests
-----

This directory contains a number of sub-directories, each of which
is a stand-alone git repository and represents one test case.

There is a bash script at the top level of each test repo which
runs each test.

Each test
1. Fires up a mongod with ``--dbpath`` set to a folder called ``testdata``
under the test folder.
2. Runs any needed setup commands in the test MongoDB instance (set state, add users, etc)
3. Executes the tool with a local configuration file writing a log file into
the local folder

The ``tests`` folder contains a harness script to run all the tests.
You can execute all tests with

```
$tests\run_all_tests.bash
```

or run indiviual tests with

```
$tests\run_one_test.bash basic_no_auth
```

where, in this case, the test we want to run is called ``basic_no_auth``

To create a new test:
1. Create a new folder
2. copy the ``mongrate.conf`` and ``test.sh`` files from an existing test
3. edit ``mongrate.conf`` and ``test.sh`` as needed
4. run ``git init`` in your new test folder, remember each of these test folders is a stand-alone git repo
5. _or_, optionally, you can put ``git`` command directly in the ``test.sh`` file. See the test ``delete_files`` for an example
6. create and edit migrations as appropriate
7. run using one of the methods above
