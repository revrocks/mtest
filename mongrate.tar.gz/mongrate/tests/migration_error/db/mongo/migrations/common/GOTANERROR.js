/*************************
* MongoDB Migration
*
* Generated on 2016-11-15 10:31:29.564006
* _id : GOTANERROR
**************************/

migration = {
  '_id' : 'GOTANERROR',
  'runAfter' : [],
  'onLoad' : function() {
      // TODO: Add onLoad logic here
      print('GOTANERROR onLoad');
      },
  'up' : function() {
      // TODO: rollforward logic
      // TODO: Be sure do 'use' right right database!
      if ( x < 100 ) {
          print("Should never get here, x is undefined");
      }
      },
  'down' : function() {
      // TODO: Add undo/rollback logic here
      // TODO: Be sure do 'use' right right database!
      },
  'info' : function() {
      // output information on this migration for reporting
      print('migration : ' + this._id)
      },
}

mongrate.exports = migration;
