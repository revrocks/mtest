/*************************
* MongoDB Migration
*
* Generated on 2016-11-09 11:50:45.817845
* _id : alice
**************************/

migration = {
  '_id' : 'alice',
  'runAfter' : ['bob'],
  'onLoad' : function() {
      // TODO: Add onLoad logic here
      print('onLoad alice');
      },
  'up' : function() {
      // TODO: rollforward logic
      // TODO: Be sure do 'use' right right database!
      },
  'down' : function() {
      // TODO: Add undo/rollback logic here
      // TODO: Be sure do 'use' right right database!
      },
  'info' : function() {
      // output information on this migration for reporting
      print('migration : ' + this._id)
      },
}

mongrate.exports = migration;
