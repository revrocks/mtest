/*************************
* MongoDB Migration
*
* Generated on 2016-11-09 11:50:33.425175
* _id : bob
**************************/

migration = {
  '_id' : 'bob',
  'runAfter' : ['alice'],
  'onLoad' : function() {
      // TODO: Add onLoad logic here
      print('onLoad bob');
      },
  'up' : function() {
      // TODO: rollforward logic
      // TODO: Be sure do 'use' right right database!
      },
  'down' : function() {
      // TODO: Add undo/rollback logic here
      // TODO: Be sure do 'use' right right database!
      },
  'info' : function() {
      // output information on this migration for reporting
      print('migration : ' + this._id)
      },
}

mongrate.exports = migration;
