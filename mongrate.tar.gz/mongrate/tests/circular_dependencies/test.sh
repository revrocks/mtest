#!/bin/bash
echo "no _id test"
echo "test db port=$MONGRATE_TEST_DB_PORT"
mkdir ./testdata
if [ $? -eq 0 ]
then
    echo "created ./testdata directory"
else
    echo "./testdata exists, it should not, test cannot continue"
    exit 1
fi

mongod --dbpath ./testdata --logpath ./testdata/mongod.log --fork --port $MONGRATE_TEST_DB_PORT

if [ $? -eq 0 ]
then
    echo "test mongod started successfully"
else
    echo "unable to start test mongod"
    exit 1
fi

latest_commit=$(git rev-list --all | head -1)
echo "Rolling forward to latest commit $latest_commit"

python $MONGRATE_HOME/mongrate.py --action initialize --verbose 
python $MONGRATE_HOME/mongrate.py --action migrate --git-commit $latest_commit --verbose
#echo "test.sh test return code was $?"

if [ $? -eq 1 ]
then
    echo "mongrate returned error => circular dependency test was successful"
    return_code=0
else
    echo "mongrate did not return an error, check test output"
    return_code=1
fi

mongo admin --port=$MONGRATE_TEST_DB_PORT --eval 'db.shutdownServer()'

rm -rf testdata/
exit $return_code


