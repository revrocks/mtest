/*************************
* MongoDB Migration
*
* Generated on 2016-11-08 15:01:51.986910
* _id : alpha
**************************/

migration = {
  '_id' : 'alpha',
  'runAfter' : [],
  'onLoad' : function() {
      // TODO: Add onLoad logic here
      print('alpha onLoad with auth!');
      var ui = db.getSiblingDB('admin').getUser('jim');
      printjson(ui);
      },
  'up' : function() {
      // TODO: rollforward logic
      // TODO: Be sure do 'use' right right database!
      print('alpha up()')
      db=db.getSiblingDB('test');
      db.alpha.createIndex({x:1,y:1});
      print('indexed for \'alpha\' collection');
      printjson(db.alpha.getIndexes());
      // count one for _id index!
      assert(db.alpha.getIndexes().length==2);
      },
  'down' : function() {
      // TODO: Add undo/rollback logic here
      // TODO: Be sure do 'use' right right database!
      print('alpha down()')
      db=db.getSiblingDB('test');
      db.alpha.dropIndex({x:1,y:1});
      print('dropped index {x:1,y:1} on \'alpha\' collection');
      printjson(db.alpha.getIndexes());
      // _id index will still be there
      assert(db.alpha.getIndexes().length==1);
      },
  'info' : function() {
      // output information on this migration for reporting
      print('migration : ' + this._id)
      },
}

mongrate.exports = migration;
