#!/bin/bash
mongo admin --port 20187 --eval 'db.shutdownServer()'
rm -rf .git
rm -rf testdata/
rm -rf db
rm mongrate.log
