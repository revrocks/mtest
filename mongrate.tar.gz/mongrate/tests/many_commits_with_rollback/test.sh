#!/bin/bash
echo "delete_file.sh test"
echo "test db port=$MONGRATE_TEST_DB_PORT"
mkdir ./testdata

if [ $? -eq 0 ]
then
    echo "created ./testdata directory"
else
    echo "./testdata exists, it should not, test cannot continue"
    exit 1
fi
mkdir -p ./db/mongo/migrations/common
if [ $? -eq 0 ]
then
    echo "created ./db/mongo/migrations/common directory"
else
    echo "./db/mongo/migrations/common exists, it should not, test cannot continue"
    exit 1
fi

mongod --dbpath ./testdata --logpath ./testdata/mongod.log --fork --port $MONGRATE_TEST_DB_PORT

if [ $? -eq 0 ]
then
    echo "test mongod started successfully"
else
    echo "unable to start test mongod"
    exit 1
fi


git init
python $MONGRATE_HOME/mongrate.py --action generate_migration --migration-id ALPHA
python $MONGRATE_HOME/mongrate.py --action generate_migration --migration-id BETA
git add db/mongo/migrations/common/ALPHA.js
git add db/mongo/migrations/common/BETA.js
git commit -a -m 'alpha,beta commit'
alpha_commit=$(git rev-list --all)
python $MONGRATE_HOME/mongrate.py --action generate_migration --migration-id GAMMA
git add db/mongo/migrations/common/GAMMA.js
git commit -a -m 'gamma commit'
gamma_commit=$(git rev-list --all | head -1)

python $MONGRATE_HOME/mongrate.py --action generate_migration --migration-id DELTA
git add db/mongo/migrations/common/DELTA.js
git commit -a -m 'delta commit'

delta_commit=$(git rev-list --all | head -1)


echo "Rolling forward to delta commit $delta_commit"
python $MONGRATE_HOME/mongrate.py --action initialize --verbose 
python $MONGRATE_HOME/mongrate.py --action migrate --git-commit $delta_commit --verbose

mongo_commit=`python $MONGRATE_HOME/mongrate.py --action status_quiet`
echo "mongo_commit=$mongo_commit"

if [ "$delta_commit" != "$mongo_commit" ]
then
    echo "mongo commit=$mongo_commit does not match expected $delta_commit"
    exit 1
fi

echo "Rolling back to alpha commit $alpha_commit"
python $MONGRATE_HOME/mongrate.py --action initialize --verbose 
python $MONGRATE_HOME/mongrate.py --action migrate --git-commit $alpha_commit --verbose

mongo_commit=`python $MONGRATE_HOME/mongrate.py --action status_quiet`
echo "mongo_commit=$mongo_commit"

if [ "$alpha_commit" != "$mongo_commit" ]
then
    echo "mongo commit=$mongo_commit does not match expected $alpha_commit"
    exit 1
fi

echo "Test complete, cleaning up"

mongo admin --port=$MONGRATE_TEST_DB_PORT --eval 'db.shutdownServer()'
rm -rf testdata/
rm -rf .git/
rm -rf db/
exit 0
