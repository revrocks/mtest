/*************************
* MongoDB Migration
*
* Generated on 2016-11-15 11:22:49.557640
* _id : foobar
**************************/

migration = {
  '_id' : 'foobar',
  'runAfter' : [],
  'onLoad' : function() {
      // TODO: Add onLoad logic here
      },
  'up' : function() {
      // TODO: rollforward logic
      // TODO: Be sure do 'use' right right database!
      },
  'down' : function() {
      // TODO: Add undo/rollback logic here
      // TODO: Be sure do 'use' right right database!
      },
  'info' : function() {
      // output information on this migration for reporting
      print('migration : ' + this._id)
      },
}

mongrate.exports = migration;
