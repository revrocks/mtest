#!/bin/bash
./run_all_tests.bash | grep -e SUCCESS -e FAIL
