#!/bin/bash
echo "staged_git_changes.sh test"
echo "this test repo has one staged change, it should fail since"
echo "mongrate will not run on a repo with staged changes!"
echo "test db port=$MONGRATE_TEST_DB_PORT"
mkdir ./testdata
mongod --dbpath ./testdata --logpath ./testdata/mongod.log --fork --port $MONGRATE_TEST_DB_PORT

latest_commit=$(git rev-list --all | head -1)
echo "Rolling forward to latest commit $latest_commit"

python $MONGRATE_HOME/mongrate.py --action initialize --verbose
python $MONGRATE_HOME/mongrate.py --action migrate --git-commit $latest_commit --verbose

mongo admin --port=$MONGRATE_TEST_DB_PORT --eval 'db.shutdownServer()'
rm -rf ./testdata


