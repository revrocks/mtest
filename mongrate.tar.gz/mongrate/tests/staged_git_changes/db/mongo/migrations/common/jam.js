/*************************
* MongoDB Migration
*
* Generated on 2016-11-16 12:10:29.842629
* _id : jam
**************************/

migration = {
  '_id' : 'jam',
  'runAfter' : [],
  'onLoad' : function() {
      // TODO: Add onLoad logic here
      },
  'up' : function() {
      // TODO: rollforward logic
      // TODO: Be sure do 'use' right right database!
      },
  'down' : function() {
      // TODO: Add undo/rollback logic here
      // TODO: Be sure do 'use' right right database!
      },
  'info' : function() {
      // output information on this migration for reporting
      print('migration : ' + this._id)
      },
}

mongrate.exports = migration;
