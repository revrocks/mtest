#!/bin/bash
echo "delete_file.sh test"
echo "test db port=$MONGRATE_TEST_DB_PORT"
mkdir ./testdata

if [ $? -eq 0 ]
then
    echo "created ./testdata directory"
else
    echo "./testdata exists, it should not, test cannot continue"
    exit 1
fi
mkdir -p ./db/mongo/migrations/common
if [ $? -eq 0 ]
then
    echo "created ./db/mongo/migrations/common directory"
else
    echo "./db/mongo/migrations/common exists, it should not, test cannot continue"
    exit 1
fi

mongod --dbpath ./testdata --logpath ./testdata/mongod.log --fork --port $MONGRATE_TEST_DB_PORT

if [ $? -eq 0 ]
then
    echo "test mongod started successfully"
else
    echo "unable to start test mongod"
    exit 1
fi


git init
python $MONGRATE_HOME/mongrate.py --action generate_migration --migration-id ALPHA
python $MONGRATE_HOME/mongrate.py --action generate_migration --migration-id BETA
git add db/mongo/migrations/common/ALPHA.js
git add db/mongo/migrations/common/BETA.js
git commit -a -m 'first commit'
first_commit=$(git rev-list --all)
git rm db/mongo/migrations/common/BETA.js
git commit -a -m 'second commit'
second_commit=$(git rev-list --all | head -1)

echo "Rolling forward to second commit $second_commit"

python $MONGRATE_HOME/mongrate.py --action initialize --verbose 
python $MONGRATE_HOME/mongrate.py --action migrate --git-commit $second_commit --verbose

mongo_commit=`python $MONGRATE_HOME/mongrate.py --action status_quiet`
echo "mongo_commit=$mongo_commit"

if [ "$second_commit" != "$mongo_commit" ]
then
    echo "mongo commit=$mongo_commit does not match expected $first_commit"
    exit 1
fi

<<'OLD_TEST'
echo "Checking out second commit $second_commit"
git checkout --quiet $second_commit
echo "Rolling forward to next commit $second_commit with deleted files"

python $MONGRATE_HOME/mongrate.py --action migrate --git-commit $second_commit --verbose

mongo_commit=$(python $MONGRATE_HOME/mongrate.py --action status_quiet)
echo "mongo_commit=$mongo_commit"

if [ "$second_commit" != "$mongo_commit" ]
then
    echo "mongo commit=$mongo_commit does not match expected $second_commit"
    exit 1
fi
OLD_TEST
echo "Test complete, cleaning up"

mongo admin --port=$MONGRATE_TEST_DB_PORT --eval 'db.shutdownServer()'
rm -rf testdata/
rm -rf .git/
rm -rf db/
exit 0
