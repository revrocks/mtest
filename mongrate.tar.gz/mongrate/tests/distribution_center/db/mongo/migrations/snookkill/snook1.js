/*************************
* MongoDB Migration
*
* Generated on 2016-11-09 15:11:27.611848
* _id : snook1
**************************/

migration = {
  '_id' : 'snook1',
  'runAfter' : ['alpha'],
  'onLoad' : function() {
      // TODO: Add onLoad logic here
      print('onLoad snookkill specific')
      },
  'up' : function() {
      // TODO: rollforward logic
      // TODO: Be sure do 'use' right right database!
      print('snookkill up()');
      db.getSiblingDB('test').getCollection('snookkill').createIndex({'a':1});
      },
  'down' : function() {
      // TODO: Add undo/rollback logic here
      // TODO: Be sure do 'use' right right database!
      print('snookkill down()');
      db.getSiblingDB('test').getCollection('snookkill').dropIndex({'a':1});
      },
  'info' : function() {
      // output information on this migration for reporting
      print('migration : ' + this._id)
      },
}

mongrate.exports = migration;
