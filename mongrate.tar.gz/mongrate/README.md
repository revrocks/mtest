mongrate
========

A git-based database schema migration tool for MongoDB.

Mongrate is a development and application maintenance tool designed
to help manage collection level meta-data in MongoDB. While MongoDB
does not require any schema-definitions or "DDLs" like other types
of databases, each collection does define schema-related items, such
as indexes, validation logic, and, with MongoDB 3.4, read-only views. The creation and removal of these types of meta-data is contained in a javascript file called a migration, which must follow a set of conventions by defining an `_id` property and then functions for applying (`up()`) and for removing (`down()`). The tool supports the ability to generate a template migration which you can then edit - so there's no need to memorize or lookup these conventions.

This tool is tightly integrated with `git`. You can give the tool a
`git` commit SHA and it will figure out what files have changed between
the current state and the target commit. The target could be ahead of
the current state or possibly behind. Mongrate will figure this out and
call an appropriate `up()` or `down()` method in migrations found in the
change list.

Here is an example migration:
<pre>
migration = {
  '_id' : 'alpha',
  'runAfter' : [],
  'onLoad' : function() {
      // TODO: Add onLoad logic here
      print('alpha onLoad');
      },
  'up' : function() {
      // TODO: rollforward logic
      // TODO: Be sure do 'use' right right database!
      print('alpha up()')
      db=db.getSiblingDB('test');
      db.alpha.createIndex({x:1,y:1});
      print('indexed for \'alpha\' collection');
      printjson(db.alpha.getIndexes());
      // count one for _id index!
      assert(db.alpha.getIndexes().length==2);
      },
  'down' : function() {
      // TODO: Add undo/rollback logic here
      // TODO: Be sure do 'use' right right database!
      print('alpha down()')
      db=db.getSiblingDB('test');
      db.alpha.dropIndex({x:1,y:1});
      print('dropped index {x:1,y:1} on \'alpha\' collection');
      printjson(db.alpha.getIndexes());
      // _id index will still be there
      assert(db.alpha.getIndexes().length==1);
      },
  'info' : function() {
      // output information on this migration for reporting
      print('migration : ' + this._id)
      },
}

mongrate.exports = migration;
</pre>

Usage
=====

This tool uses a combination of a configration file and command line arguments.

See the [tests](tests) folder for numerous examples.

Disclaimer
==========

This tool is provided as an example.
It is not officially supported by MongoDB.

Credits
=======
jason.mimick@mongodb.com
mihail.chirita@gap.com
samir.doshi@gap.com
