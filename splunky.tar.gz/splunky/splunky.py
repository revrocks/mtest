#!/usr/bin/env python

# splunky.py - POST oplog from a given collection to SPLUNK

import sys,time,os
import signal
import argparse
import pymongo
from pymongo import MongoClient, CursorType, ReturnDocument
import bson
import datetime
from threading import Thread
import logging
import yaml
import atexit
import requests
from requests import RequestException
from bson.json_util import dumps

class App():

    def __init__(self,args,config,logger):
        signal.signal(signal.SIGTERM, self.sigterm_handler)
        self.stop_called = False
        self.stop_requested = False
        self.config = config
        self.args = args
        self.logger = logger
        self.decorate_mongo_connection_string()
        self.doc_count = 0
        if self.config['numRetriesReadingOplog']:
            self.numRetriesReadingOplog = self.config['numRetriesReadingOplog']
        else:
            logger.info('numRetriesReadingOplog not found in config, defaulting to 5')
            self.numRetriesReadingOplog = 5
        if self.config['failedOplogReadSleepTimeSeconds']:
            self.failedOplogReadSleepTimeSeconds = self.config['failedOplogReadSleepTimeSeconds']
        else:
            logger.info('failedOplogReadSleepTimeSeconds not found in config, defaulting to 5')
            self.failedOplogReadSleepTimeSeconds = 5
        self.logger.info('splunky=%s'%self)
        self.logger.info("initialized for operation")

    def run(self):
        self.logger.info("run called")
        self.tail()

    def vprint(self,message):
        if self.args.verbose==True:
            self.logger.debug(message)

    def tail(self):
        self.logger.info('splunky tailing oplog for %s' % self.args.namespace)
        try:
            #self.tail_ns()
            self.TAIL_ERROR = {}
            t = Thread(target=self.extail_ns)
            t.setDaemon(True)
            t.start()
            while True:
                t.join(20)
                if self.TAIL_ERROR:
                    raise self.TAIL_ERROR
            self.logger.info('main thread ending')
        except BaseException as error:
            self.logger.error(error)
            raise error

    def extail_ns(self):
        try:
            self.tail_ns()
        except BaseException as error:
            self.TAIL_ERROR = error

    def tail_ns(self):
        # connect up to mongodb
        ns = self.args.namespace
        nsp = ns.split('.')
        db_name = nsp[0]
        coll_name = '.'.join(nsp[1:])
        local_oplog = 'oplog.' + coll_name
        connection = pymongo.MongoClient(self.config['mongodb'])
        # test db connection this will raise error if issue
        self.vprint( connection.server_info() )
        local_db = connection['local']
        db = connection[db_name]
        query = { "ns" : ns }

        # make sure the connection can read from local db!
        try:
            self.logger.info('testing reading from oplog')
            count = local_db['oplog.rs'].count()
            self.logger.info('test OK, total number of docs in oplog=%s' % str(count))
        except pymongo.errors.OperationFailure as opfail:
            self.logger.error('test FAILED, check credentials are authorized to read on local db')
            raise opfail

        if local_oplog in db.collection_names():
            try:
                last_local_oplog_entry = db[local_oplog].find({}).sort("ts",-1).limit(1).next()
                query["ts"]={ "$gt" : last_local_oplog_entry['ts'] }
            except StopIteration:   #thrown when out of data so wait a little
                self.vprint(db_name+"."+local_oplog+' exists, but no entries found')
        else:
            self.vprint('SPLUNK mode, but '+local_oplog+' not found. Inserting initial seed')
            doc = { '_id' : self.config['splunkLastUpdateId'], 'ts' : bson.timestamp.Timestamp(datetime.datetime.now(),0), 'doc' : 0 }
            self.try_insert(db,local_oplog,doc)
            self.vprint('initial seed=%s inserted into %s' % (doc,local_oplog))
        self.logger.info('starting to tail oplog with query=%s' % query)
        #start tailable cursor
        oplog = connection['local']['oplog.rs'].find(query,cursor_type = CursorType.TAILABLE_AWAIT)
        if 'ts' in query:
            oplog.add_option(8)     # oplogReplay
        headers = { "Authorization" : "Splunk " + self.config['splunkToken'],
                    "X-Splunk-Request-Channel" :
                        self.config['X-Splunk-Request-Channel'] }
        mongo_host = pymongo.uri_parser.parse_uri(self.config['mongodb'])['nodelist'][0][0]
        while oplog.alive:
            try:
                if self.stop_requested:
                    self.logger.info("Tail for " + local_oplog + " stopping.")
                    oplog.close()
                    break
                else:
                    doc = {}
                    for i in range(self.numRetriesReadingOplog):
                        try:
                            doc = oplog.next()
                        except pymongo.errors.AutoReconnect as ar:
                            st = i * self.failedOplogReadSleepTimeSeconds
                            m = 'error reading oplog try #%s of %s, sleeping %s seconds' % (ar,str(i),st)
                            self.logger.error(m)
                            self.logger.error(ar)
                            time.sleep(st)
                    if not doc:
                        raise Exception('Unable to read from oplog, check errors in splunky log')

                    self.vprint(doc)
                    # Send the document to SPLUNK
                    requests.packages.urllib3.disable_warnings()
                    dataToSend = { "event" : doc
                                   ,"index" : self.config['splunkIndex']
                                   ,"source" : self.config['splunkSource']
                                   ,"host" : mongo_host }
                    ds = sys.getsizeof(dataToSend)
                    if ds > self.config['maxDataSizeToSendToSplunkInBytes']:
                        self.logger.info('Message size=%s over max' % str(ds))
                        if self.config['stopOnDataSizeOverMaxSize']:
                            self.logger.error('stopOnDataSizeOverMaxSize was True, spluny will stop')
                            self.logger.error('dataToSend=%s' % dataToSend)
                            raise Exception('message over max size')
                        else:
                            self.logger.info('stopOnDataSizeOverMaxSize was False, splunky shall skip and continue')
                            self.try_update_last_doc_splunk(db,local_oplog,doc)
                            continue

                    self.logger.debug('POSTing size~%s' % (str(ds)))
                    self.vprint(headers)
                    url = self.config['httpEndpoint']
                    self.vprint(dumps(dataToSend))
                    self.try_post(url,dumps(dataToSend),headers)
                    self.try_update_last_doc_splunk(db,local_oplog,doc)
                    self.doc_count += 1
                    if self.doc_count%100==0:
                        self.log_docs_sent()
                    #time.sleep(20)
            except StopIteration as si:   #thrown when out of data so wait a little
                self.vprint("sleep")
                st = self.config['tailSleepTimeSeconds']
                self.logger.debug('si=%s'%si)
                self.logger.info('at end of oplog for %s, snoozing %s seconds' % (ns,str(st)))
                self.log_docs_sent()
                time.sleep(st)


    def log_docs_sent(self):
        self.logger.info('docs sent this run=%s' % (str(self.doc_count)))

    def try_post(self,url,data,headers):
        r = self.config['numRetriesOnErrorSendingToSplunk']
        for i in range(r):
            try:
                response = requests.post(url,data=data,headers=headers,verify=False)
                response.raise_for_status()
                self.vprint(vars(response))
                return
            except RequestException as re:
                self.logger.error('error sending POST to %s, attempt %s of %s' % (url,str(i),str(r)))
                self.logger.error(re)
                self.logger.error('tried to send data=%s' % data)
                time.sleep(pow(2,i))
            except Exception as e:
                # other exceptions, not requests related, should be kicked up
                self.logger.error(e)
                raise e
        # if here, then post failed 3 times - log fatal error and stop
        m = 'unable to send POST to %s after 3 attempts' % url
        self.logger.critical(m)
        if self.config['stopOnErrorSendingToSplunk']:
            raise Exception('stopOnErrorSendingToSplunk was True, splunky will stop')
        else:
            self.logger.critical('stopOnErrorSendingToSplunk was False, splunky will move on')


    def try_insert(self,db,coll_name, doc):
        for i in range(5):
            try:
                uid = self.config['splunkLastUpdateId']
                wr = db[coll_name].insert_one({"_id": uid,"ts": doc['ts']})
                self.vprint(dir(wr))       # TODO: Check write result!
                self.vprint("Inserted into " + coll_name)
                return
            except pymongo.errors.AutoReconnect:
                self.logger.error("AutoReconnect error, try #" + str(i))
                time.sleep(pow(2, i))
            except Exception as e:
                self.logger.error(e)
                raise e
        # if here, then we failed 5 times - log fatal error
        self.logger.critical('unable to insert doc into %s - MongoDB unavailable?' % coll_name)
        raise Exception("Unable to insert into MongoDB")

    def try_update_last_doc_splunk(self,db,coll_name, doc):
        self.vprint("try_update_last_doc_splunk")
        for i in range(5):
            try:
                uq = { '_id' : self.config['splunkLastUpdateId'] }
                ud = {"$set": {"ts" : doc['ts'] } }
                ud['$inc'] = { 'docs_sent' : 1 }
                wr = db[coll_name].update_one(uq,ud)
                sd = db[coll_name].find_one_and_update(uq,ud, return_document=ReturnDocument.AFTER)
                self.vprint('sd=%s'%sd)
                if sd['docs_sent']%50==0:
                    self.logger.info('total docs set=%s' % sd['docs_sent'])
                return
            except pymongo.errors.AutoReconnect:
                self.logger.error("AutoReconnect error, try #" + str(i))
                time.sleep(pow(2, i))
            except Exception as e:
                self.logger.error(e)
                raise e
        # if here, then we failed 5 times - log fatal error
        self.logger.critical("Unable to update document into " + coll_name + " - MongoDB unavailable?")
        raise Exception("Unable to insert into MongoDB")

    def shutdown(self,needToWait=True):
        self.logger.info('cleanup starting needToWait=%s' % str(needToWait))
        self.stop_requested = True
        # need to sleep a little longer than the tailing thread
        # would sleep, to make sure it can clean up properly and
        # not be in the middle of something
        if needToWait:
            st = self.config['tailSleepTimeSeconds'] + 2
            self.logger.info('waiting %s seconds for tail to cleanup' % str(st))
            time.sleep(st)       # sleep to let tailing thread cleanup
        self.logger.info("cleanup complete - splunky shutting down.")

    def sigterm_handler(self,signo,stack_frame):
        self.logger.info('got signal %s' % signo)
        self.shutdown()
        sys.exit(1)

    def decorate_mongo_connection_string(self):
        """Adds in any runtime auth args to the connection string in the conf file."""
        got_user = self.args.user
        got_pwd = self.args.password
        need_to_fix_uri = False
        if self.args.user:
            self.logger.debug('got_user was True, attempting to fix MongoDB URI')
            need_to_fix_uri = True
        if self.args.password:
            self.logger.debug('got_pwd was True, attempting to fix MongoDB URI')
            need_to_fix_uri = True
        if not need_to_fix_uri:
            self.logger.debug('don\'t need to fix MongoDB URI')
            self.config['masked_mongodb']=self.config['mongodb']
            return
        cs = self.config['mongodb']
        self.config['original.mongodb'] = cs    # save off just in case
        parsed_cs = pymongo.uri_parser.parse_uri(cs)
        self.logger.debug('1 parsed_cs=%s' % parsed_cs)
        if self.args.user:
            parsed_cs['username']=self.args.user
            self.logger.debug('updated MongoDB URI with username from args')
        if self.args.password:
            parsed_cs['password']=self.args.password
            self.logger.debug('updated MongoDB URI with password from args')
        self.logger.debug('parsed_cs=%s' % parsed_cs)
        ncs = 'mongodb://'
        ncs += '%s:' % parsed_cs['username']
        ncs += '%s@' % parsed_cs['password']
        for n in parsed_cs['nodelist']:
            ncs += '%s:%s,' % (n[0],n[1])
        ncs = ncs[:-1] + '/'  #replace last comma with forward slash
        if parsed_cs['database']:
            ncs += '%s?' % parsed_cs['database']
        if self.args.authenticationDatabase:
            parsed_cs['options']['authsource']=self.args.authenticationDatabase
            self.logger.debug('updated MongoDB URI with authSource from authenticationDatabase argument')
        # When using uri for connection string and also --eval in the shell
        # the 'authsource' parameter seems to be case sensistive
        # ensure this item is 'authSource' not 'authsource'
        if 'authsource' in parsed_cs['options']:
            parsed_cs['options']['authSource']=parsed_cs['options']['authsource']
            del parsed_cs['options']['authsource']

        for k in parsed_cs['options']:
            ncs += '%s=%s&' % (k,parsed_cs['options'][k])
        ncs = ncs[:-1]      # trim trailing &
        self.config['mongodb']=ncs
        # mask password for any logging
        if len(self.config['mongodb'].split('@'))>0:
            parts = self.config['mongodb'].split('@')
            b = parts[0].split(':')
            b[2]="XXXXXXXXX"
            self.config['masked_mongodb']=':'.join(b)+'@'+parts[1]

        self.logger.debug('mongodb=%s' % self.config['masked_mongodb'])

def main():
    # parse arguments
    description = 'splunky - POST oplog entries from a collection to Splunk'
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("-n","--namespace"
                        ,help='namespace to send oplog entries to Splunk, each instance of spluker sends entries from one collection')
    parser.add_argument("-f","--config",default="./mongrate.conf",help='Configuration file see docs')
    parser.add_argument("-u","--user",help="user name for MongoDB connection, overrides conf connection string")
    parser.add_argument("-p","--password",help="password for MongoDB connection, overrides conf connection string")
    parser.add_argument("--authenticationDatabase",help="user source, --user and --password are required for this argument to be applied")
    parser.add_argument("--verbose",action='store_true',default=False
                        ,help='Enable more verbose logging')


    args = parser.parse_args()
    config = yaml.safe_load(open(args.config))
    logger = logging.getLogger("splunky")
    logger.setLevel(getattr(logging,config.get('loglevel','INFO').upper()))
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    if 'logfile' in config:
        handler = logging.FileHandler(os.path.abspath(config['logfile']))
    else:
        handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.info("log level set to " + logging.getLevelName(logger.getEffectiveLevel()))
    logger.info("args: " + str(args))
    logger.info("config: " + str(config))
    try:
        app = App(args,config,logger)
        app.run()
    except KeyboardInterrupt,SystemExit:
        logger.info('received exit signal, attempting shutdown')
        app.shutdown()
        sys.exit(0)
    except Exception as exp:
	logger.error(exp)
        app.shutdown(needToWait=False)
        if args.verbose:
            raise
	sys.exit(1)


if __name__ == '__main__':
    main()

